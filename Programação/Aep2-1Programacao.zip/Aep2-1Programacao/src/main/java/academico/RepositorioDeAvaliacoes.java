package academico;

import java.util.ArrayList;
import java.util.List;

public class RepositorioDeAvaliacoes {
	public List<Avaliacao> avaliacoes = new ArrayList();
	
	public void adicionar(Avaliacao avaliacao) {
		avaliacoes.add(avaliacao);
	}
	
	public Aluno[] obterAprovados(Disciplina disciplina) {
		Aluno[] aprovados;
		Aluno[] alunos;
		float[] notas;
		float[] media;
		
		for(Avaliacao avaliacao : avaliacoes) {
			if(avaliacao.getDisciplina() == disciplina && avaliacao) {
				
			}
		}
		
		return aprovados;
	}
}
