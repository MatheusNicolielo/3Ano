package academico;

public class Disciplina {
	private String nome;
	
	public Disciplina(String nome) {
		this.nome = nome;
	}

	public String getNome() {
		return nome;
	}
}
